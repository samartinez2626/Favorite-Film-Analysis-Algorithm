/*
========================================
Project: My Favorite Films Analyzer
Author: Sammy Martinez
Date: 10/29/25
Description:
========================================
*/
//outline of this was made w the help of ChatGPT
// Raw Data Data Layer


//::::::::::::::::::::::::::: All Available Film Data (Data Layer)
const allFilms = [
  { title: "Spiderman: Across the Spiderverse", genre: "Sci-Fi", rating: 4.4, year: 2023 },
  { title: "Bottoms", genre: "Comedy", rating: 3.8, year: 2023 },
  { title: "Bright Future", genre: "Mystery", rating: 3.7, year: 2002 },
  { title: "A Silent Voice", genre: "Drama", rating: 4.2, year: 2017 },
  { title: "Cats", genre: "Musical", rating: 1.3, year: 2019 }
];

//::::::::::::::::::::::::::: Get Random Subset of Films
function getRandomFilms() {
  // Shuffle and take 2–5 random films each time
  const shuffled = [...allFilms].sort(() => 0.5 - Math.random());
  const count = Math.floor(Math.random() * (allFilms.length - 1)) + 2; // 2–5 films
  return shuffled.slice(0, count);
}

//::::::::::::::::::::::::::: Convert Data into Information
function analyzeFilms(data) {
  const avgRating = (data.reduce((sum, film) => sum + film.rating, 0) / data.length).toFixed(2);
  const topFilm = data.reduce((best, film) => (film.rating > best.rating ? film : best));

  return {
    totalFilms: data.length,
    averageRating: avgRating,
    topFilm: topFilm
  };
}

//::::::::::::::::::::::::::: Generate Knowledge (Insights & Advice)
function generateInsights(data, analysis) {
  // Recommend any films rated 3.8 stars or higher
  const recommendations = data.filter(f => f.rating >= 3.8).map(f => f.title);
  let advice;

  if (analysis.averageRating > 3.8) {
    advice = "Ur taste is like mine which means youre fun and good and quirky and better than everyone else 😌🎬✨";
  } else if (analysis.averageRating > 3.7) {
    advice = "Ur taste is ok and acceptable🍿";
  } else {
    advice = "Yk what...we all got guilty pleasures😃";
  }

  return { recommendations, advice };
}

//::::::::::::::::::::::::::: Display Results
document.getElementById("analyzeBtn").addEventListener("click", () => {
  const filmData = getRandomFilms(); // Random subset each time
  const analysis = analyzeFilms(filmData);
  const insights = generateInsights(filmData, analysis);

  const outputDiv = document.getElementById("output");
  outputDiv.innerHTML = `
    🎞️ <strong>Total Films Analyzed:</strong> ${analysis.totalFilms}
    ⭐ <strong>Average Rating:</strong> ${analysis.averageRating} / 5
    🏆 <strong>Top Film:</strong> ${analysis.topFilm.title} (${analysis.topFilm.rating})

    🍿 <strong>Recommended Films (≥3.8):</strong> 
    ${insights.recommendations.length ? insights.recommendations.join(", ") : "None this round 😅"}

    💡 <strong>Insight:</strong> ${insights.advice}
  `;
});
